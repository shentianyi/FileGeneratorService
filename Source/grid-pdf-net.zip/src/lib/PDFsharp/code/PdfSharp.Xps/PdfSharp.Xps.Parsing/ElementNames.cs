﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.Parsing
{
  ///// <summary>
  ///// Names of the XPS classes.
  ///// </summary>
  //static class ElementNames
  //{
  //  public const string Canvas = "Canvas";
  //  public const string FixedPage = "FixedPage";
  //  public const string Glyphs = "Glyphs";
  //  public const string MatrixTransform = "MatrixTransform";
  //  public const string Path = "Path";
  //  public const string PathGeometry = "PathGeometry";

  //  public const string ImageBrush = "ImageBrush";
  //  public const string SolidColorBrush = "SolidColorBrush";
  //  public const string LinearGradientBrush = "LinearGradientBrush";
  //  public const string RadialGradientBrush = "RadialGradientBrush";
  //  public const string VisualBrush = "VisualBrush";
  //}
}